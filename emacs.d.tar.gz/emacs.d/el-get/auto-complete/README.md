Auto Complete Mode
==================

[![Build Status](https://secure.travis-ci.org/auto-complete/auto-complete.png)](http://travis-ci.org/auto-complete/auto-complete)

**FOR BEST RESULTS, USE AT LEAST EMACS REVISION 110135**. You'll need to build from source, at least until Emacs 24.3 is officially released. Earlier revisions contain a nasty bug that can cause your Emacs to segfault when using auto-complete. 

Documentation
-------------

* http://cx4a.org/software/auto-complete/
* doc/index.txt

License
-------

Auto Complete Mode is distributed under the term of GPLv3. And its documentations under doc directory is distributed under the term of GFDL.
