# Emacs Setup on MS Windows

You can download Emacs for Windows here: http://ftp.gnu.org/gnu/emacs/windows/

further instructions:
todo
