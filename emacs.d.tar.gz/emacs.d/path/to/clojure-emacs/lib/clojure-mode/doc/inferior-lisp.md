# Inferior Lisp

todo: copy content from <http://dev.clojure.org/display/doc/Getting+Started+with+Emacs>
